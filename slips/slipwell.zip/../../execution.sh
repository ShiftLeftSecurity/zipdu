#!/usr/bin/env bash

readonly UPLOAD_FOLDER=./uploads

rm -rf "${UPLOAD_FOLDER}"
echo "This script slipped through and the upload folder is now gone."
