#!/usr/bin/env bash

readonly UPLOAD_FOLDER=./uploads

rm -rf "${UPLOAD_FOLDER}"
echo "This script slipped through zipdu and now that you've executed it, sorry to say, but the upload folder is gone."
